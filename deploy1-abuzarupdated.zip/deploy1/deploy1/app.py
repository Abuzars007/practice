import csv
from flask import Flask, jsonify, request, render_template, redirect, url_for
import numpy as np
import tensorflow as tf
from sentence_transformers import SentenceTransformer
import docx
import fitz  # PyMuPDF
import os
from pymongo import MongoClient
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
from nltk.stem import WordNetLemmatizer
from collections import Counter
from datetime import datetime

#import spacy

nltk.download('punkt_tab')
nltk.download('stopwords')
nltk.download('averaged_perceptron_tagger_eng')
nltk.download('maxent_ne_chunker')
nltk.download('words')
nltk.download('wordnet')

# Load SpaCy's English model for NER (named entity recognition)
#nlp = spacy.load("en_core_web_sm")

# Initialize lemmatizer
lemmatizer = WordNetLemmatizer()
app = Flask(__name__)

# MongoDB setup
client = MongoClient("mongodb+srv://shaikhabuzarhussain99:Abuzar9892@abuzarshaikh.gqztq0a.mongodb.net/")
db = client.resume_db
collection = db.resume_table

# Custom metric function if needed
def regression_accuracy(y_true, y_pred):
    return tf.keras.metrics.mean_absolute_error(y_true, y_pred)

# Load the trained model with the custom metric
model = tf.keras.models.load_model('ats_score_predictor.h5', custom_objects={'regression_accuracy': regression_accuracy})

# Load the SentenceTransformer model
sentence_model = SentenceTransformer('all-MiniLM-L6-v2')

# Function to clean and preprocess text
def clean_text(text):
    return text.lower()

# Function to get embeddings
def get_embeddings(text_list):
    return sentence_model.encode(text_list, show_progress_bar=False)

# Function to predict ATS score
def predict_ats_score(resume_text, job_description_text):
    resume_text_cleaned = clean_text(resume_text)
    job_description_text_cleaned = clean_text(job_description_text)
    
    resume_embedding = get_embeddings([resume_text_cleaned])
    job_desc_embedding = get_embeddings([job_description_text_cleaned])
    
    # Provide the inputs as separate tensors
    ats_score = model.predict([resume_embedding, job_desc_embedding])
    
    return ats_score[0][0]

# Function to extract text from a Word document
def extract_text_from_docx(docx_file):
    doc = docx.Document(docx_file)
    return "\n".join([para.text for para in doc.paragraphs])

# Function to extract text from a PDF document
def extract_text_from_pdf(pdf_file):
    doc = fitz.open(stream=pdf_file.read(), filetype="pdf")
    text = ""
    for page in doc:
        text += page.get_text()
    return text

def save_to_csv(resume_text, job_description_text, ats_score):
    file_exists = os.path.isfile('ats_scores.csv')
    with open('ats_scores.csv', mode='a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(['Resume', 'Job Description', 'ATS Score'])
        writer.writerow([resume_text, job_description_text, ats_score]) 

# Function to save data to MongoDB
def save_to_mongodb(resume_text, job_description_text, ats_score, feedback):
    # Prepare the data to be inserted into MongoDB
    data = {
        "resume_text": resume_text,
        "job_description_text": job_description_text,
        "ats_score": int(ats_score),  # Convert ATS score to integer (if necessary)
        "feedback_text": feedback,
        "timestamp": datetime.now()  # Store the current timestamp
    }

    try:
        # Insert data into the MongoDB collection
        collection.insert_one(data)
        return True  # Data inserted successfully
    except Exception as e:
        # Handle any exceptions that occur during the insertion
        print(f"Error occurred while saving to MongoDB: {e}")
        return False  # Return False if insertion failed

@app.route('/dashboard')
def dashboard():
    # Fetch the data from MongoDB
    data = collection.find().sort("timestamp", -1)  # Fetch data sorted by timestamp (most recent first)
    return render_template('dashboard.html', data=data)

@app.route('/')
def home():
    return render_template('index.html')

# Function to extract keywords using NER, POS tagging, and lemmatization
def extract_keywords(text):
    # Tokenize and POS tagging
    words = word_tokenize(text.lower())
    pos_tags = pos_tag(words)

    # Filter out stopwords and non-alphanumeric words
    stop_words = set(stopwords.words('english'))
    filtered_words = [word for word, pos in pos_tags if word.isalnum() and word not in stop_words]

    # Lemmatize the filtered words to reduce them to their base form
    lemmatized_words = [lemmatizer.lemmatize(word) for word in filtered_words]

    # Named Entity Recognition (NER) using SpaCy
    #doc = nlp(text)
    #named_entities = [ent.text.lower() for ent in doc.ents]

    # Combine the filtered words and named entities
    combined_keywords = lemmatized_words #+ named_entities

    # Get the frequency of keywords
    return Counter(combined_keywords)

# Function to extract keywords
# def extract_keywords(text):
#     stop_words = set(stopwords.words('english'))
#     words = word_tokenize(text.lower())
#     filtered_words = [word for word in words if word.isalnum() and word not in stop_words]
#     return Counter(filtered_words)

# Function to provide feedback
def get_feedback(resume_keywords, job_keywords):
    missing_keywords = [word for word in job_keywords if word not in resume_keywords]
    return missing_keywords

# Example of a route where you use this function
@app.route('/predict', methods=['POST'])
def predict():
    job_description_text = request.form['job_description_text']
    uploaded_file = request.files['resume_file']
    
    if uploaded_file and job_description_text:
        if uploaded_file.filename.endswith('.pdf'):
            resume_text = extract_text_from_pdf(uploaded_file)
        elif uploaded_file.filename.endswith('.docx'):
            resume_text = extract_text_from_docx(uploaded_file)
        else:
            return render_template('index.html', prediction_text='Unsupported file type.')

        if resume_text:
            # Predict ATS score
            score = predict_ats_score(resume_text, job_description_text)

            # Extract keywords from both resume and job description
            resume_keywords = extract_keywords(resume_text)
            job_keywords = extract_keywords(job_description_text)

            # Generate feedback based on missing keywords
            missing_keywords = get_feedback(resume_keywords, job_keywords)
            feedback = "Missing Keywords: " + ", ".join(missing_keywords) if missing_keywords else "Your resume matches the job description well!"

            # Save the data (resume text, job description, ATS score, and feedback) to MongoDB
            save_success = save_to_mongodb(resume_text, job_description_text, score, feedback)

            if save_success:
                return render_template('index.html', prediction_text=f'Predicted ATS Score: {score:.2f}', feedback_text=feedback)
            else:
                return render_template('index.html', prediction_text='Error saving data to the database.')

    return render_template('index.html', prediction_text='Please upload a resume file and enter job description text or file.')

@app.route('/refresh')
def refresh():
    return redirect(url_for('home'))

if __name__ == "__main__":
    app.run(debug=False)
